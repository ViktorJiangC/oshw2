#ifndef SYSCALL_H
#define SYSCALL_H

#include "syscall_ids.h"

void syscall();

#endif // SYSCALL_H
